"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";
import { assets } from "@/lib/assets";

export function HeroSection() {
  const [loaded, setLoaded] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    // Short delay for entrance animation
    const timer = setTimeout(() => setLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const scrollDown = () => {
    document.querySelector("#overview")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="hero"
      className="relative h-screen min-h-[600px] w-full overflow-hidden bg-[var(--color-deep-navy)]"
      aria-label="HUM Sapphire hero section"
    >
      {/* Background image */}
      <div className="absolute inset-0">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={assets.heroImage}
          alt="HUM Sapphire – G+21 luxury residences in Borivali West"
          className="h-full w-full object-cover object-center"
          style={{
            transform: "scale(1.04)",
            transition: "transform 1.4s cubic-bezier(0.16,1,0.3,1)",
            ...(loaded ? { transform: "scale(1)" } : {}),
          }}
        />
        {/* Cinematic gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/20 to-black/70" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex h-full flex-col justify-end pb-24 lg:pb-20 px-6 lg:px-16 xl:px-24">
        {/* Label */}
        <div
          className="flex items-center gap-4 mb-6"
          style={{
            opacity: loaded ? 1 : 0,
            transform: loaded ? "translateY(0)" : "translateY(20px)",
            transition: "opacity 0.9s ease 0.4s, transform 0.9s ease 0.4s",
          }}
        >
          <span className="gold-line" />
          <p className="label-sm text-[var(--color-gold)] tracking-[0.25em]">
            Gorai · Borivali West · Mumbai
          </p>
        </div>

        {/* Main headline */}
        <h1
          className="heading-xl text-white max-w-[14ch] mb-6"
          style={{
            opacity: loaded ? 1 : 0,
            transform: loaded ? "translateY(0)" : "translateY(30px)",
            transition: "opacity 1s ease 0.6s, transform 1s ease 0.6s",
          }}
        >
          Where Elevation
          <br />
          <em>Meets Living.</em>
        </h1>

        {/* Sub text */}
        <p
          className="body-lg text-white/70 max-w-[46ch] mb-10"
          style={{
            opacity: loaded ? 1 : 0,
            transform: loaded ? "translateY(0)" : "translateY(20px)",
            transition: "opacity 0.9s ease 0.85s, transform 0.9s ease 0.85s",
          }}
        >
          Premium 2 &amp; 3 BHK residences in a G+21 storey tower.
          Thoughtfully crafted for modern families in the heart of Borivali West.
        </p>

        {/* CTAs */}
        <div
          className="flex flex-wrap items-center gap-4"
          style={{
            opacity: loaded ? 1 : 0,
            transform: loaded ? "translateY(0)" : "translateY(20px)",
            transition: "opacity 0.9s ease 1.05s, transform 0.9s ease 1.05s",
          }}
        >
          <button
            onClick={() => document.querySelector("#enquiry")?.scrollIntoView({ behavior: "smooth" })}
            className="label-md bg-[var(--color-gold)] text-[var(--color-deep-navy)] px-8 py-3.5 hover:bg-[var(--color-gold-light)] transition-colors duration-300"
          >
            Enquire Now
          </button>
          <button
            onClick={() => document.querySelector("#overview")?.scrollIntoView({ behavior: "smooth" })}
            className="label-md text-white border border-white/30 px-8 py-3.5 hover:border-[var(--color-gold)] hover:text-[var(--color-gold)] transition-colors duration-300"
          >
            Explore Project
          </button>
        </div>

        {/* Project badge */}
        <div
          className="hidden lg:flex absolute right-16 xl:right-24 bottom-20 flex-col items-end gap-1"
          style={{
            opacity: loaded ? 1 : 0,
            transition: "opacity 1s ease 1.2s",
          }}
        >
          <p className="label-sm text-white/50">MahaRERA</p>
          <p className="label-sm text-[var(--color-gold)]">PM1180002601373</p>
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={scrollDown}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-white/60 hover:text-white transition-colors"
        aria-label="Scroll to explore"
        style={{
          opacity: loaded ? 1 : 0,
          transition: "opacity 1s ease 1.4s",
        }}
      >
        <span className="label-sm tracking-[0.2em] text-white/40">Scroll</span>
        <ChevronDown
          size={18}
          className="animate-bounce"
          style={{ animationDuration: "2s" }}
        />
      </button>
    </section>
  );
}
